<?php

require_once("db.php");

class DBJSON extends DB {
	protected $archivo;

	function guardarUsuario(Usuario $usuario) {
	
	}

	function traerTodos() {
		
	}

	function traerPorMail($email) {

	}
}

?>